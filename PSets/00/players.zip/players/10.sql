SELECT "first_name" AS 'Players who throws with R' FROM "players"
WHERE "throws" = 'R'ORDER BY "first_name";
