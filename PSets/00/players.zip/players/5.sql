SELECT "first_name", "last_name" FROM "players" WHERE "bats" = 'R'
ORDER BY "first_name", "last_name";
