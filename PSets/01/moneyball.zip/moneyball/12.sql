SELECT "players"."first_name", "players"."last_name"
FROM "players" JOIN "performances"
ON "players"."id" = "performances"."player_id"
JOIN "salaries"
ON "players"."id" = "salaries"."player_id" AND "salaries"."year" = "performances"."year"
WHERE "salaries"."year" = 2001 AND "performances"."H" != 0 AND "performances"."RBI" != 0
ORDER BY "salaries"."salary" / "performances"."H", "salaries"."salary" / "performances"."RBI", "players"."id"
LIMIT 10;